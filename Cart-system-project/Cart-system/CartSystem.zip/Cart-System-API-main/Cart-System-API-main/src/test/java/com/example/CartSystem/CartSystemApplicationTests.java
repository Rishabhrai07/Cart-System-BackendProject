package com.example.CartSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
